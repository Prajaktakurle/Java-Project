package com.cg.training.client.Exercise2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.training.service.exercise2.FileDetails;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class FileDemo {

	public static void main(String rr[])throws IOException
	{
		FileDemo fd=new FileDemo();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the location of the file to be analysed : ");
		String s=br.readLine();
		//FileInputStream f=new FileInputStream("D:\\FilePrgm.txt");
		FileDetails.analyze(s);
	}
}