package com.cg.training.labExercise6.Exercise1;

import java.util.Comparator;

public class sortByValue implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
