package com.cg.training.labExercise6.Exercise1;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

//import javax.swing.text.html.HTMLDocument.Iterator;

public class Exercise1 {
	public static void main(String[] args)
	{
		HashMap<String, Integer> hashmap=new HashMap<String, Integer>();
		hashmap.put("Angular", 98);
		hashmap.put("Spring", 85);
		hashmap.put("SQL", 91);
		hashmap.put("Java", 95);
		List<Integer> output=sortByValue(hashmap);
		System.out.println("Sorted list:"+ output);
		
	}
	public static List<Integer> sortByValue(HashMap<String, Integer>hashmap) 
	{
		List list=new LinkedList(hashmap.entrySet());
		System.out.println(list);
		Collections.sort(list, new sortByValue());
		List result=new LinkedList();
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Map.Entry map=(Map.Entry )it.next();
			result.add(map.getValue());
		}
		return result;
	}

}
